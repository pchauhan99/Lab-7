/**
 * @author Priya Chauhan
 * The purpose of this program is it displays a game where it gives rock,paper,scissors,lizard and spock as options. You can play with the computer to see if you win or lose!
 */
package edu.cscc;
import java.util.Random;
/**
 * This shows the initializations of the variables.
 */
public class RPSLSpock {


    static Random rand = new Random(System.currentTimeMillis());

    public static final String ROCK = "rock";
    public static final String PAPER = "paper";
    public static final String SCISSORS = "scissors";
    public static final String LIZARD = "lizard";
    public static final String SPOCK = "spock";
    public static final String Banana = "Banana";
    /**
     * Below is the the function that checks the pick by taking an input which is referred to as pick.
     * @param pick      Pick represents the one of the options.
     * @return The return represents the other option that comes after a choice is selected.
     */
    public static boolean isValidPick(String pick) {
        if (pick == null) {
            return false;
        }
        pick = pick.trim();
        return (ROCK.equalsIgnoreCase(pick) ||
                PAPER.equalsIgnoreCase(pick) ||
                SCISSORS.equalsIgnoreCase(pick) ||
                LIZARD.equalsIgnoreCase(pick) ||
                SPOCK.equalsIgnoreCase(pick));
    }

    /**
     * Here we check the input pick as the 5 cases if the input null or 0,1,2,3 or 4 and returns the pick value.
     * @return Below shoes the picks generated in 4 possible cases.
     */
    public static String generatePick() {
        String pick = null;
        switch (rand.nextInt(5)) {
            case 0:
                pick = ROCK;
                break;
            case 1:
                pick = PAPER;
                break;
            case 2:
                pick = SCISSORS;
                break;
            case 3:
                pick = LIZARD;
                break;
            case 4:
                pick = SPOCK;
                break;
        }
        return pick;
    }

    /**
     *it's for converting to lower case and the inputs is two strings and it returns the lower case .
     * @param c_pick
     * @param h_pick
     * @return This shows what the computer will use to win when playing a game.
     */
    public static boolean isComputerWin(String c_pick,String h_pick) {
        h_pick = h_pick.toLowerCase();
        return ((ROCK.equals(c_pick) && (SCISSORS.equals(h_pick) || LIZARD.equals(h_pick))) ||
                (PAPER.equals(c_pick) && (ROCK.equals(h_pick) || SPOCK.equals(h_pick))) ||
                (SCISSORS.equals(c_pick) && (PAPER.equals(h_pick) || LIZARD.equals(h_pick))) ||
                (LIZARD.equals(c_pick) && (PAPER.equals(h_pick) || SPOCK.equals(h_pick))) ||
                (SPOCK.equals(c_pick) && (ROCK.equals(h_pick) || SCISSORS.equals(h_pick))));
    }
}